//
//  MovieBookingApp.swift
//  MovieBooking
//
//  Created by Fadhil on 2022-11-30.
//

import SwiftUI

@main
struct MovieBookingApp: App {

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
