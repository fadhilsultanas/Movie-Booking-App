//
//  PosterData.swift
//  MovieBooking
//
//  Created by Fadhil on 2022-11-29.
//

import Foundation

var posters1: [String] = ["poster1", "poster2", "poster3", "poster4", "poster5", "poster6"]

var posters2: [String] = ["poster7", "poster8", "poster9", "poster10", "poster11", "poster12"]

var posters3: [String] = ["poster13", "poster14", "poster15", "poster16", "poster17", "poster18"]
